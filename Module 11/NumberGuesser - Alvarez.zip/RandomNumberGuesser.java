/* Nestor J Alvarez
   CS 111B, Professor Schatz
   19 April 2016
*/
import java.util.*;

public class RandomNumberGuesser extends NumberGuesser {

   public RandomNumberGuesser() {
      super();
   }
   
   public RandomNumberGuesser(int lowerBound, int upperBound) {
      super(lowerBound, upperBound);
   }

   protected int getMidPoint(int min, int max) {
   
         Random random = new Random();
         
         return random.nextInt(max - min) + min;
   
//       int diff = (int) Math.ceil((max - min) / 2.0);
//       return max - diff;
   
   }

}