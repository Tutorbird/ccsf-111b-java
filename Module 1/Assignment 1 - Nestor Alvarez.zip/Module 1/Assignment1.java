/**
 * Nestor Alvarez
 * CS 11B Spring 2016
 * 21 January 2016
 */

import java.util.Scanner;

public class Assignment1 {
  public static void main(String[] args) {
    int count = 0;
    char repeat = 'y';
    Scanner input = new Scanner(System.in);
    
      while (repeat == 'y' || repeat == 'Y') {
         System.out.println("How many asterisks? ");
         count = input.nextInt();
         for (int i = 0; i < count; i++) {
            System.out.print("*");
        }
         System.out.print("\nGo again? (y/n)");
         repeat = input.next().charAt(0);
    }
    
      System.out.println("I have no use anymore... good bye.");
    
  }
}