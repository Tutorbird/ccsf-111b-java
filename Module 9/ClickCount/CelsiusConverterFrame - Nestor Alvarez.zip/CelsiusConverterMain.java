/*
  Nestor J Alvarez
  CS 111B, Prof. Jason Schatz
  20150405
 */

import javax.swing.*;

public class CelsiusConverterMain {

	public static void main(String[] args) {
		JFrame frame = new CelsiusConverterFrame();

		frame.setVisible(true);
	}
}